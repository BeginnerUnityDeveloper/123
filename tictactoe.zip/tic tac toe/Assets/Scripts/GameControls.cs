﻿using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEditor.Compilation;
using UnityEditor.MemoryProfiler;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.UIElements;

public class GameControls : MonoBehaviour
{
    Vector3 mouse;
    private int Turn;
    private int end = 0;
    //int[] field = new int[9];
    public GameObject[] crosses = new GameObject[9];
    public GameObject[] circles = new GameObject[9];
    public GameObject GameOverCrosses;
    public GameObject GameOverCircles;
    public GameObject Draw;

    // Start is called before the first frame update
    void Start()
    {
        zeroeverything();
    }

    //при запуску нової гри анульовую всі значення
    void zeroeverything()
    {
        Turn = 0;
        GameOverCrosses.SetActive(false);
        GameOverCircles.SetActive(false);
        Draw.SetActive(false);
        for (int i = 0; i < 9; i++)
        {
            crosses[i].SetActive(false);
            circles[i].SetActive(false);
        }
    }

    // Update is called once per frame
    void Update()
    {

    }

    //перевіряю де клацнули мишкою
    public void OnMouseDown()
    {
        mouse = Input.mousePosition;
        if (end == 1)
        {
            end = 0;
            zeroeverything();
        }
        else if ((mouse.x > 232 && mouse.x < 381) && (mouse.y > 330 && mouse.y < 462))
            filling(0);
        else if ((mouse.x > 386 && mouse.x < 533) && (mouse.y > 330 && mouse.y < 462))
            filling(1);
        else if ((mouse.x > 538 && mouse.x < 687) && (mouse.y > 330 && mouse.y < 462))
            filling(2);
        else if ((mouse.x > 232 && mouse.x < 381) && (mouse.y > 193 && mouse.y < 324))
            filling(3);
        else if ((mouse.x > 386 && mouse.x < 533) && (mouse.y > 193 && mouse.y < 324))
            filling(4);
        else if ((mouse.x > 538 && mouse.x < 687) && (mouse.y > 193 && mouse.y < 324))
            filling(5);
        else if ((mouse.x > 232 && mouse.x < 381) && (mouse.y > 58 && mouse.y < 187))
            filling(6);
        else if ((mouse.x > 386 && mouse.x < 533) && (mouse.y > 58 && mouse.y < 187))
            filling(7);
        else if ((mouse.x > 538 && mouse.x < 687) && (mouse.y > 58 && mouse.y < 187))
            filling(8);
    }

    //помічаю клітинку, де клацнули мишкою
    void filling(int square)
    {
        //if (field[square] == 0 || field[square] == 1)
        //    return;
        if (crosses[square].activeSelf || circles[square].activeSelf)
            wincheck();

        else if (Turn == 0)
        {
            //field[square] = Turn;
            crosses[square].SetActive(true);
            Turn++;
            wincheck();
        }

        else
        {
            //field[square] = Turn;
            circles[square].SetActive(true);
            Turn--;
            wincheck();
        }
    }

    //перевірка на перемогу або нічию
    void wincheck()
    {
        if ((crosses[0].activeSelf && crosses[1].activeSelf && crosses[2].activeSelf)
            || (crosses[3].activeSelf && crosses[4].activeSelf && crosses[5].activeSelf)
            || (crosses[6].activeSelf && crosses[7].activeSelf && crosses[8].activeSelf))
        {
            GameOverCrosses.SetActive(true);
            end++;
        }
        else if ((crosses[0].activeSelf && crosses[3].activeSelf && crosses[6].activeSelf)
            || (crosses[1].activeSelf && crosses[4].activeSelf && crosses[7].activeSelf)
            || (crosses[2].activeSelf && crosses[5].activeSelf && crosses[8].activeSelf))
        {
            GameOverCrosses.SetActive(true);
            end++;
        }
        else if ((crosses[0].activeSelf && crosses[4].activeSelf && crosses[8].activeSelf)
            || (crosses[2].activeSelf && crosses[4].activeSelf && crosses[6].activeSelf))
        {
            GameOverCrosses.SetActive(true);
            end++;
        }
        else if ((circles[0].activeSelf && circles[1].activeSelf && circles[2].activeSelf)
            || (circles[3].activeSelf && circles[4].activeSelf && circles[5].activeSelf)
            || (circles[6].activeSelf && circles[7].activeSelf && circles[8].activeSelf))
        {
            GameOverCircles.SetActive(true);
            end++;
        }
        else if ((circles[0].activeSelf && circles[3].activeSelf && circles[6].activeSelf)
            || (circles[1].activeSelf && circles[4].activeSelf && circles[7].activeSelf)
            || (circles[2].activeSelf && circles[5].activeSelf && circles[8].activeSelf))
        {
            GameOverCircles.SetActive(true);
            end++;
        }
        else if ((circles[0].activeSelf && circles[4].activeSelf && circles[8].activeSelf)
            || (circles[2].activeSelf && circles[4].activeSelf && circles[6].activeSelf))
        {
            GameOverCircles.SetActive(true);
            end++;
        }
        else if((crosses[0].activeSelf || circles[0].activeSelf) && (crosses[1].activeSelf || circles[1].activeSelf)
            && (crosses[2].activeSelf || circles[2].activeSelf)
            && (crosses[3].activeSelf || circles[3].activeSelf) && (crosses[4].activeSelf || circles[4].activeSelf)
            && (crosses[5].activeSelf || circles[5].activeSelf)
            && (crosses[6].activeSelf || circles[6].activeSelf) && (crosses[7].activeSelf || circles[7].activeSelf)
            && (crosses[8].activeSelf || circles[8].activeSelf))
        {
            Draw.SetActive(true);
            end++;
        }
    }

}
